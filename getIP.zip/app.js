const express = require("express");
const cors = require("cors");
const app = express();
const extIP = require("ext-ip")();
const dotenv = require("dotenv").config();

// CORS
app.use(cors());
app.use(express.json({ limit: "1mb" }));

////////////// TESTING  ////////////////////////////
// app.enable("trust proxy", true);
app.get("/", async (req, res) => {
  try {
    // using  npm ext-ip------------------
    const ext = extIP.get();
    const extIp = await ext;

    return res.status(200).json({
      status: true,
      message: "User Ip retrieved successfully",
      ip: { extIp },
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      status: false,
      message: "Server Error. Please try again",
      error: error,
    });
  }
});

const PORT = process.env.PORT;
app.listen(PORT, (res) => {
  console.log(`The app running is in http://localhost:${PORT}`);
});
